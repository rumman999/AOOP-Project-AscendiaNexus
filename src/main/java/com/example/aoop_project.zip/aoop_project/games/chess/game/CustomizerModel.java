package com.example.aoop_project.games.chess.game;

public class CustomizerModel extends ChessBoardModel{

    CustomizerModel(){
        super();
    }



}
