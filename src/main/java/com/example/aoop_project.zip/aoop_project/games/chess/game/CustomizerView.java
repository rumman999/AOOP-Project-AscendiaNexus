package com.example.aoop_project.games.chess.game;

public class CustomizerView extends ChessBoardView {

    public CustomizerView(){
        super();
    }

}
